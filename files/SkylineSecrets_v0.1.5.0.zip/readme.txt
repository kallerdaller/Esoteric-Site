Skyline Secrets is a two player strategic card game about an intense resource competition between two cities,
in their attempt to make the perfect fireworks display.
Both players have access to the same options of play and therefore the game is decided on skillful plays and outwitting your opponent.


Matches take less than five minutes to complete and the game has a very easy learning curve, with difficulty in mastery.

The game is free to play however modifications are not permitted and cannot be redistributed.

Donations are accpeted on the itch.io page. (https://kallerdaller.itch.io/skyline-secrets)

Support email: darley0alex1@gmail.com
Or Discord alternative: kaller#2653

Join our discord group at https://discord.gg/vXtm4gN


Windows SmartScreen blocking the app? Click more info and then run anyway. 
Reason why it does this? We don't pay Microsoft to not display this.
Technical explaination? Each executable file must have a certificate to prove its authenticity. You basically pay a company to test
the software for viruses and they award it with a certificate. Problem is, A) it costs money, B) each update would need this doing
So we opted not to do this and just hope that it wouldn't deter too many people away :)
(this doesn't happen with Steam games as they have their own virus checking and certificate system that is automatic).