Esoteric is a two player strategic card game about an intense resource competition between two cities,
in their attempt to make the perfect fireworks display.
Both players have access to the same options of play and therefore the game is decided on skillful plays and outwitting your opponent.


Matches take less than five minutes to complete and the game has a very easy learning curve, with difficulty in mastery.

The game is free to play however modifications are not permitted and cannot be redistributed.

Donations are accpeted on the itch.io page.

Support email: darley0alex1@gmail.com
Or Discord alternative: kaller#2653

Join our discord group at https://discord.gg/vXtm4gN